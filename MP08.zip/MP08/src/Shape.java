public class Shape {

    public double getArea() {
        return 0.0;
    }
    protected double getPerimeter() {
        return 0.0;
    }

    @Override
    public String toString() {
        return "Shape";
    }
}
