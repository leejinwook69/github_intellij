public class DigitCounter extends CharCounter{
    DigitCounter(String s) {
        super(s);
    }

    @Override
    void GetCharCount() {

    }
}