public class WhiteSpaceCounter extends CharCounter{
    WhiteSpaceCounter(String s) {
        super(s);
    }

    @Override
    void GetCharCount() {

    }
}